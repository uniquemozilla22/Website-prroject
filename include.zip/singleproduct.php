<?php
include("include/header.include.php");
include("include/banner.include.php");
include("include/products/singleproduct.include.php");
include("include/footer.include.php");