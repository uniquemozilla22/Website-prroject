<?php

include("include/header.include.php");
include("include/banner.include.php");
include("include/traders/traderlist.include.php");
include("include/footer.include.php");