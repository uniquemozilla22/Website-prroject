<?php

include("include/header.include.php");
include("include/banner.include.php");
include("include/about/description.include.php");
include("include/about/team.include.php");
include("include/footer.include.php");