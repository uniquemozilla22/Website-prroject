<?php
include("include/header.include.php");
include("include/banner.include.php");
include("include/products/sidebar.include.php");
include("include/footer.include.php");